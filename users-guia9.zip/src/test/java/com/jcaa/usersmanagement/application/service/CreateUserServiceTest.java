package com.jcaa.usersmanagement.application.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.jcaa.usersmanagement.application.port.out.CreateAccountPort;
import com.jcaa.usersmanagement.application.port.out.GetUserByEmailPort;
import com.jcaa.usersmanagement.application.port.out.SaveUserPort;
import com.jcaa.usersmanagement.application.port.out.UpdateUserPort;
import com.jcaa.usersmanagement.application.service.dto.command.CreateUserCommand;
import com.jcaa.usersmanagement.domain.enums.UserRole;
import com.jcaa.usersmanagement.domain.enums.UserStatus;
import com.jcaa.usersmanagement.domain.exception.AccountCreationException;
import com.jcaa.usersmanagement.domain.exception.UserAlreadyExistsException;
import com.jcaa.usersmanagement.domain.model.UserModel;
import com.jcaa.usersmanagement.domain.valueobject.UserEmail;
import com.jcaa.usersmanagement.domain.valueobject.UserId;
import com.jcaa.usersmanagement.domain.valueobject.UserName;
import com.jcaa.usersmanagement.domain.valueobject.UserPassword;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Tests para CreateUserService.
 *
 * <p>Cubre: validación del command, email duplicado y flujo feliz (save + notificación).
 */
@DisplayName("CreateUserService")
@ExtendWith(MockitoExtension.class)
class CreateUserServiceTest {

  @Mock private SaveUserPort saveUserPort;
  @Mock private GetUserByEmailPort getUserByEmailPort;
  @Mock private EmailNotificationService emailNotificationService;
  @Mock private CreateAccountPort createAccountPort;
  @Mock private UpdateUserPort updateUserPort;

  private CreateUserService service;

  @BeforeEach
  void setUp() {
    try (final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
      service =
          new CreateUserService(
              saveUserPort,
              getUserByEmailPort,
              emailNotificationService,
              createAccountPort,
              updateUserPort,
              validatorFactory.getValidator());
    }
  }

  // ── flujo feliz

  @Test
  @DisplayName("execute() guarda el usuario y envía notificación cuando el email no existe")
  void shouldSaveUserAndNotifyWhenEmailIsNew() {
    // Arrange
    final CreateUserCommand command =
        new CreateUserCommand("u-01", "John Arrieta", "john@example.com", "Pass1234", "ADMIN");

    final UserModel savedUser =
        new UserModel(
            new UserId("u-01"),
            new UserName("John Arrieta"),
            new UserEmail("john@example.com"),
            UserPassword.fromPlainText("Pass1234"),
            UserRole.ADMIN,
            UserStatus.PENDING);

    when(getUserByEmailPort.getByEmail(any())).thenReturn(Optional.empty());
    when(saveUserPort.save(any())).thenReturn(savedUser);
    when(updateUserPort.update(savedUser.activate())).thenReturn(savedUser.activate());

    // Act
    final UserModel result = service.execute(command);

    // Assert
    assertAll(
        "flujo feliz de CreateUserService",
        () -> assertNotNull(result, "resultado no debe ser null"),
        () -> assertEquals("u-01", result.getId().value(), "id del usuario guardado"),
        () -> assertEquals(UserStatus.ACTIVE, result.getStatus(), "pasa a ACTIVE con cuenta"));

    verify(saveUserPort).save(any(UserModel.class));
    verify(emailNotificationService).notifyUserCreated(savedUser, "Pass1234");
    verify(createAccountPort).createAccount(savedUser);
    verify(updateUserPort).update(savedUser.activate());
  }

  // ── accounts no disponible

  @Test
  @DisplayName("execute() devuelve el usuario en PENDING si accounts falla")
  void shouldReturnSavedUserWhenAccountCreationFails() {
    // Arrange
    final CreateUserCommand command =
        new CreateUserCommand("u-03", "Ana Perez", "ana@example.com", "Pass1234", "MEMBER");

    final UserModel savedUser =
        new UserModel(
            new UserId("u-03"),
            new UserName("Ana Perez"),
            new UserEmail("ana@example.com"),
            UserPassword.fromPlainText("Pass1234"),
            UserRole.MEMBER,
            UserStatus.PENDING);

    when(getUserByEmailPort.getByEmail(any())).thenReturn(Optional.empty());
    when(saveUserPort.save(any())).thenReturn(savedUser);
    doThrow(AccountCreationException.becauseServiceRejected("u-03", 500))
        .when(createAccountPort)
        .createAccount(savedUser);

    // Act
    final UserModel result = service.execute(command);

    // Assert
    assertEquals("u-03", result.getId().value());
    assertEquals(UserStatus.PENDING, result.getStatus(), "sin cuenta se queda en PENDING");
    verify(emailNotificationService).notifyUserCreated(savedUser, "Pass1234");
    verify(updateUserPort, never()).update(any());
  }

  // ── email duplicado

  @Test
  @DisplayName("execute() lanza UserAlreadyExistsException cuando el email ya está registrado")
  void shouldThrowWhenEmailAlreadyExists() {
    // Arrange
    final CreateUserCommand command =
        new CreateUserCommand("u-02", "Jane Doe", "jane@example.com", "Pass5678", "MEMBER");

    final UserModel existing =
        new UserModel(
            new UserId("u-99"),
            new UserName("Jane Doe"),
            new UserEmail("jane@example.com"),
            UserPassword.fromPlainText("OtraPass1"),
            UserRole.MEMBER,
            UserStatus.ACTIVE);

    when(getUserByEmailPort.getByEmail(any())).thenReturn(Optional.of(existing));

    // Act & Assert
    assertThrows(UserAlreadyExistsException.class, () -> service.execute(command));
    verify(saveUserPort, never()).save(any());
    verify(emailNotificationService, never()).notifyUserCreated(any(), any());
    verify(createAccountPort, never()).createAccount(any());
  }

  // ── validación del command

  @Test
  @DisplayName(
      "execute() lanza ConstraintViolationException cuando el command tiene campos inválidos")
  void shouldThrowWhenCommandIsInvalid() {
    // Arrange — id en blanco y email inválido
    final CreateUserCommand command =
        new CreateUserCommand("", "Jo", "not-an-email", "short", "ADMIN");

    // Act & Assert
    assertThrows(ConstraintViolationException.class, () -> service.execute(command));
    verifyNoInteractions(
        saveUserPort,
        getUserByEmailPort,
        emailNotificationService,
        createAccountPort,
        updateUserPort);
  }
}
